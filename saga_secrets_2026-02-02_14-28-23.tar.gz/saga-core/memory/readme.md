/saga/memory/
├── README.md                ← this spec (authoritative)
├── consensus.jsonl          ← explicit, user-authorized truths
├── emergent.jsonl           ← Saga-observed patterns (tentative)
├── topics.jsonl             ← semantic tags & interests
├── summaries.jsonl          ← boiled-down knowledge
├── patterns.jsonl           ← deduped conversation loops
└── verbatim/
    ├── dnd/
    │   └── helheim.jsonl
    ├── smarthome/
    │   └── home_config.jsonl
    └── misc/
