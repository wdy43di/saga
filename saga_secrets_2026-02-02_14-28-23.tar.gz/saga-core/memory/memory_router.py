import os
import json
import hashlib
from datetime import datetime
from typing import Optional

# =========================
# Configuration
# =========================

MEMORY_BASE = os.environ.get("SAGA_MEMORY_PATH", "/saga/memory")

VALID_KINDS = {"explicit", "emergent", "summary", "system"}
VALID_THREADS = {
    "identity",
    "preferences",
    "projects",
    "relationships",
    "knowledge",
    "meta",
}

# =========================
# Utilities
# =========================

def _hash(content: str) -> str:
    return hashlib.sha256(content.lower().strip().encode()).hexdigest()

def _now() -> str:
    return datetime.utcnow().isoformat() + "Z"

# =========================
# Core Memory Writer
# =========================

def write_memory(
    *,
    kind: str,
    content: str,
    source: str,
    thread: str,
    confidence: float = 1.0,
) -> None:
    """
    Write a memory entry to disk with deduplication.
    """

    if kind not in VALID_KINDS:
        raise ValueError(f"Invalid memory kind: {kind}")

    if thread not in VALID_THREADS:
        raise ValueError(f"Invalid memory thread: {thread}")

    content = content.strip()
    memory_id = _hash(f"{kind}:{thread}:{content}")

    record = {
        "id": memory_id,
        "timestamp": _now(),
        "kind": kind,
        "thread": thread,
        "content": content,
        "source": source,
        "confidence": round(confidence, 2),
    }

    path = os.path.join(MEMORY_BASE, kind, f"{thread}.jsonl")
    os.makedirs(os.path.dirname(path), exist_ok=True)

    # Deduplication check
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    existing = json.loads(line)
                    if existing.get("id") == memory_id:
                        return  # already stored
                except json.JSONDecodeError:
                    continue

    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

# =========================
# Emergent Memory Detection
# =========================

def maybe_emergent_memory(text: str) -> Optional[dict]:
    """
    Detect low-confidence emergent memories from raw user text.
    """
    lowered = text.lower()

    if "linux" in lowered:
        return {
            "kind": "emergent",
            "content": "User shows preference for Linux-based systems",
            "thread": "preferences",
            "confidence": 0.4,
        }

    if "docker" in lowered:
        return {
            "kind": "emergent",
            "content": "User frequently works with Docker containers",
            "thread": "preferences",
            "confidence": 0.45,
        }

    return None

# =========================
# Public Entry Point
# =========================

def process_user_text(text: str) -> None:
    """
    Entry point called by saga_server or conversation loop.
    """
    emergent = maybe_emergent_memory(text)
    if emergent:
        write_memory(
            kind=emergent["kind"],
            content=emergent["content"],
            source="saga",
            thread=emergent["thread"],
            confidence=emergent["confidence"],
        )
