import os
import json

MEMORY_BASE = os.environ.get("SAGA_MEMORY_PATH", "/saga/memory")

def recall_projects(limit: int = 3) -> list[dict]:
    path = os.path.join(MEMORY_BASE, "summary", "projects.jsonl")
    if not os.path.exists(path):
        return []

    records = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    records.sort(key=lambda r: r.get("timestamp", ""), reverse=True)
    return records[:limit]
